&lt;?php
$koneksi = mysqli_connect(&quot;localhost&quot;,&quot;root&quot;,&quot;&quot;,&quot;program_sederhana&quot;);
// Check connection
if (mysqli_connect_errno()){
echo &quot;Koneksi database gagal : &quot; . mysqli_connect_error();
}
?&gt;