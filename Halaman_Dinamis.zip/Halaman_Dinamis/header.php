<!DOCTYPE html>
<html>
<head>
	<title>Halaman Dinamis dengan PHP</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<header>
		<h2>SMKN 7 BALEENDAH</h2> <p>Membuat Halaman Dinamis dengan PHP</p>
	</header>
	<div id="navbar">
		<div class="nav">
			<a href="index.php?home">Home</a>
			<a href="index.php?article">Article</a>
			<a href="index.php?about">About</a>
			<a href="index.php?contact">Contact</a>
		</div>
	</div>
	<!-- navbar -->
	<div class="konten">