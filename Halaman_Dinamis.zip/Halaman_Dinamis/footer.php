</div>
<!-- konten -->
<footer>
	<p>Coppyright 2019 | SMKN 7 BALEENDAH</p>
</footer>
</body>
</html>